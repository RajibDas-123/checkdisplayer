export interface Check {
  id: string
  checkNumber: number
  date: string
  creditCardNumber: string
  payee: string
  amount: number
  status: "Cleared" | "Pending" | "Bounced" | "Voided"
}
