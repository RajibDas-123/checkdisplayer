"use client"

import { useState } from "react"
import { format } from "date-fns"
import { CalendarIcon, CreditCard, FileCheck, Search, Loader2, CheckCircle2 } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Badge } from "@/components/ui/badge"
import { cn } from "@/lib/utils"
import { mockChecks } from "@/lib/mock-data"
import type { Check } from "@/lib/types"

export default function CheckSearchInterface() {
  const [checkNumber, setCheckNumber] = useState("")
  const [creditCardNumber, setCreditCardNumber] = useState("")
  const [date, setDate] = useState<Date | undefined>(undefined)
  const [searchPerformed, setSearchPerformed] = useState(false)
  const [foundChecks, setFoundChecks] = useState<Check[]>([])
  const [isLoading, setIsLoading] = useState(false)
  const [activeCheckIndex, setActiveCheckIndex] = useState(0)

  // Search for checks based on input criteria
  const handleSearch = () => {
    // Validate that at least one search field is filled
    if (!checkNumber && !creditCardNumber && !date) {
      alert("Please enter at least one search criteria")
      return
    }

    setIsLoading(true)

    // Simulate API call with a delay
    setTimeout(() => {
      let results = [...mockChecks]

      if (checkNumber) {
        results = results.filter((check) => check.checkNumber.toString() === checkNumber)
      }

      if (creditCardNumber) {
        results = results.filter((check) => check.creditCardNumber.includes(creditCardNumber))
      }

      if (date) {
        const selectedDate = format(date, "yyyy-MM-dd")
        results = results.filter((check) => format(new Date(check.date), "yyyy-MM-dd") === selectedDate)
      }

      setFoundChecks(results)
      setSearchPerformed(true)
      setIsLoading(false)
      setActiveCheckIndex(0)
    }, 800) // Reduced delay for better responsiveness
  }

  // Reset search form
  const handleReset = () => {
    setCheckNumber("")
    setCreditCardNumber("")
    setDate(undefined)
    setSearchPerformed(false)
    setFoundChecks([])
  }

  // Format currency
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
    }).format(amount)
  }

  // Get status badge color
  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case "cleared":
        return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300"
      case "pending":
        return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300"
      case "bounced":
        return "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300"
      default:
        return "bg-slate-100 text-slate-800 dark:bg-slate-800 dark:text-slate-300"
    }
  }

  // Navigate between checks
  const nextCheck = () => {
    if (activeCheckIndex < foundChecks.length - 1) {
      setActiveCheckIndex(activeCheckIndex + 1)
    }
  }

  const prevCheck = () => {
    if (activeCheckIndex > 0) {
      setActiveCheckIndex(activeCheckIndex - 1)
    }
  }

  return (
    <div className="h-screen overflow-hidden flex flex-col">
      {/* Header - Reduced height */}
      <div className="text-center py-3">
        <div className="inline-flex items-center justify-center mb-1">
          <div className="relative">
            <div className="absolute inset-0 rounded-full bg-blue-600 blur-lg opacity-20"></div>
            <div className="relative bg-gradient-to-br from-blue-500 to-blue-600 text-white p-3 rounded-full">
              <FileCheck className="h-6 w-6" />
            </div>
          </div>
        </div>
        <h1 className="text-2xl font-bold tracking-tight mb-1 bg-gradient-to-r from-blue-600 to-blue-800 bg-clip-text text-transparent">
          Check Finder
        </h1>
        <p className="text-muted-foreground text-sm max-w-md mx-auto">
          Search for your check by entering the details below
        </p>
      </div>

      {/* Main Content - Takes remaining height */}
      <div className="flex-1 overflow-hidden px-4 pb-4">
        <div className="h-full grid grid-cols-1 lg:grid-cols-12 gap-4">
          {/* Search Form - Left Side */}
          <div className="lg:col-span-5 h-full">
            <Card className="shadow-lg border-slate-200 dark:border-slate-800 overflow-hidden h-full flex flex-col">
              <div className="h-1 bg-gradient-to-r from-blue-500 to-blue-600 w-full"></div>
              <CardHeader className="bg-slate-50 dark:bg-slate-900 border-b py-3">
                <CardTitle className="text-lg">Search Checks</CardTitle>
                <CardDescription className="text-xs">Enter one or more details to find your check</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4 pt-4 flex-1 overflow-auto">
                <div className="grid gap-4">
                  <div className="grid gap-1">
                    <Label htmlFor="checkNumber" className="text-sm font-medium">
                      Check Number
                    </Label>
                    <div className="relative">
                      <div className="absolute left-3 top-2.5 text-slate-400">
                        <FileCheck className="h-4 w-4" />
                      </div>
                      <Input
                        id="checkNumber"
                        placeholder="Enter check number"
                        value={checkNumber}
                        onChange={(e) => setCheckNumber(e.target.value)}
                        className="pl-9 border-slate-200 dark:border-slate-700"
                      />
                    </div>
                  </div>

                  <div className="grid gap-1">
                    <Label htmlFor="creditCardNumber" className="text-sm font-medium">
                      Credit Card Number
                    </Label>
                    <div className="relative">
                      <div className="absolute left-3 top-2.5 text-slate-400">
                        <CreditCard className="h-4 w-4" />
                      </div>
                      <Input
                        id="creditCardNumber"
                        placeholder="Enter credit card number"
                        value={creditCardNumber}
                        onChange={(e) => setCreditCardNumber(e.target.value)}
                        className="pl-9 border-slate-200 dark:border-slate-700"
                      />
                    </div>
                  </div>

                  <div className="grid gap-1">
                    <Label className="text-sm font-medium">Date</Label>
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button
                          variant="outline"
                          className={cn(
                            "w-full justify-start text-left font-normal border-slate-200 dark:border-slate-700",
                            !date && "text-muted-foreground",
                          )}
                        >
                          <CalendarIcon className="mr-2 h-4 w-4 text-slate-400" />
                          {date ? format(date, "PPP") : "Select date"}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar
                          mode="single"
                          selected={date}
                          onSelect={setDate}
                          initialFocus
                          className="rounded-md border"
                        />
                      </PopoverContent>
                    </Popover>
                  </div>
                </div>
              </CardContent>
              <CardFooter className="flex justify-between bg-slate-50 dark:bg-slate-900 border-t py-3">
                <Button variant="outline" onClick={handleReset} className="border-slate-200 dark:border-slate-700">
                  Clear
                </Button>
                <Button
                  onClick={handleSearch}
                  className="bg-blue-600 hover:bg-blue-700 text-white"
                  disabled={isLoading}
                >
                  {isLoading ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Searching...
                    </>
                  ) : (
                    <>
                      <Search className="mr-2 h-4 w-4" />
                      Search
                    </>
                  )}
                </Button>
              </CardFooter>
            </Card>
          </div>

          {/* Check Display - Right Side */}
          <div className="lg:col-span-7 h-full">
            <Card className="shadow-lg border-slate-200 dark:border-slate-800 overflow-hidden h-full flex flex-col">
              <div className="h-1 bg-gradient-to-r from-blue-500 to-blue-600 w-full"></div>
              <CardHeader className="bg-slate-50 dark:bg-slate-900 border-b py-3">
                <div className="flex justify-between items-center">
                  <div>
                    <CardTitle className="text-lg">Check Details</CardTitle>
                    <CardDescription className="text-xs">
                      {searchPerformed
                        ? foundChecks.length > 0
                          ? `Found ${foundChecks.length} ${foundChecks.length === 1 ? "check" : "checks"}`
                          : "No checks found"
                        : "Enter search criteria to find checks"}
                    </CardDescription>
                  </div>
                  {foundChecks.length > 1 && (
                    <div className="flex items-center space-x-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={prevCheck}
                        disabled={activeCheckIndex === 0}
                        className="h-8 w-8 p-0 rounded-full"
                      >
                        &lt;
                      </Button>
                      <span className="text-sm">
                        {activeCheckIndex + 1} / {foundChecks.length}
                      </span>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={nextCheck}
                        disabled={activeCheckIndex === foundChecks.length - 1}
                        className="h-8 w-8 p-0 rounded-full"
                      >
                        &gt;
                      </Button>
                    </div>
                  )}
                </div>
              </CardHeader>
              <CardContent className="flex-1 p-0 overflow-auto">
                {isLoading ? (
                  <div className="flex flex-col items-center justify-center h-full">
                    <Loader2 className="h-12 w-12 text-blue-600 animate-spin" />
                    <p className="mt-4 text-muted-foreground">Searching for checks...</p>
                  </div>
                ) : !searchPerformed ? (
                  <div className="flex flex-col items-center justify-center h-full text-center px-4">
                    <div className="relative mb-4">
                      <div className="absolute inset-0 rounded-full bg-slate-400 blur-lg opacity-10"></div>
                      <div className="relative bg-gradient-to-br from-slate-200 to-slate-300 dark:from-slate-700 dark:to-slate-800 p-4 rounded-full">
                        <Search className="h-8 w-8 text-slate-500 dark:text-slate-400" />
                      </div>
                    </div>
                    <h3 className="text-lg font-medium mb-2">No check selected</h3>
                    <p className="text-muted-foreground max-w-sm">
                      Use the search form on the left to find your check. Enter a check number, credit card number, or
                      select a date.
                    </p>
                  </div>
                ) : foundChecks.length === 0 ? (
                  <div className="flex flex-col items-center justify-center h-full text-center px-4">
                    <div className="relative mb-4">
                      <div className="absolute inset-0 rounded-full bg-orange-400 blur-lg opacity-10"></div>
                      <div className="relative bg-gradient-to-br from-orange-100 to-orange-200 dark:from-orange-900 dark:to-orange-800 p-4 rounded-full">
                        <Search className="h-8 w-8 text-orange-500 dark:text-orange-400" />
                      </div>
                    </div>
                    <h3 className="text-lg font-medium mb-2">No checks found</h3>
                    <p className="text-muted-foreground max-w-sm">
                      We couldn't find any checks matching your search criteria. Please try different search terms.
                    </p>
                    <Button
                      variant="outline"
                      onClick={handleReset}
                      className="mt-4 border-slate-200 dark:border-slate-700"
                    >
                      Reset Search
                    </Button>
                  </div>
                ) : (
                  <div className="p-4 h-full overflow-auto">
                    {/* Check Display */}
                    <div className="h-full flex items-center justify-center">
                      <div className="w-full max-w-3xl">
                        {/* Background pattern for check */}
                        <div className="relative">
                          <div className="absolute inset-0 opacity-5">
                            <div
                              className="absolute inset-0"
                              style={{
                                backgroundImage:
                                  "url(\"data:image/svg+xml,%3Csvg width='20' height='20' viewBox='0 0 20 20' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='%23000000' fillOpacity='1' fillRule='evenodd'%3E%3Ccircle cx='3' cy='3' r='1'/%3E%3Ccircle cx='13' cy='13' r='1'/%3E%3C/g%3E%3C/svg%3E\")",
                                backgroundSize: "10px 10px",
                              }}
                            ></div>
                          </div>

                          {/* Check content */}
                          <div className="border-2 rounded-lg overflow-hidden bg-white dark:bg-slate-900 shadow-lg relative">
                            {/* Check Header with bank logo */}
                            <div className="bg-gradient-to-r from-blue-500 to-blue-600 px-4 py-3 text-white">
                              <div className="flex justify-between items-center">
                                <div className="flex items-center">
                                  <div className="font-bold text-lg mr-2">SecureBank</div>
                                  <CreditCard className="h-4 w-4" />
                                </div>
                                <div className="text-base font-semibold">
                                  Check #{foundChecks[activeCheckIndex].checkNumber}
                                </div>
                              </div>
                            </div>

                            {/* Check Body - Styled like a paper check */}
                            <div className="p-4 bg-gradient-to-r from-slate-50 to-white dark:from-slate-900 dark:to-slate-800 relative">
                              {/* Watermark */}
                              <div className="absolute inset-0 flex items-center justify-center opacity-[0.03] pointer-events-none">
                                <div className="text-black dark:text-white text-7xl font-bold rotate-45 select-none">
                                  VOID
                                </div>
                              </div>

                              {/* Date and Status */}
                              <div className="flex justify-between items-start mb-4">
                                <div>
                                  <p className="text-xs text-muted-foreground">Date</p>
                                  <p className="font-medium text-sm">
                                    {format(new Date(foundChecks[activeCheckIndex].date), "MMMM d, yyyy")}
                                  </p>
                                </div>
                                <Badge
                                  className={cn(
                                    getStatusColor(foundChecks[activeCheckIndex].status),
                                    "text-xs px-2 py-0.5",
                                  )}
                                >
                                  {foundChecks[activeCheckIndex].status}
                                </Badge>
                              </div>

                              {/* Pay To */}
                              <div className="mb-4">
                                <p className="text-xs text-muted-foreground">Pay to the order of</p>
                                <div className="border-b-2 border-dashed border-slate-300 dark:border-slate-700 py-1">
                                  <p className="font-medium">{foundChecks[activeCheckIndex].payee}</p>
                                </div>
                              </div>

                              {/* Amount */}
                              <div className="flex justify-between items-center mb-4">
                                <div className="border-2 border-slate-300 dark:border-slate-700 rounded px-3 py-1 bg-white dark:bg-slate-950">
                                  <p className="font-bold">{formatCurrency(foundChecks[activeCheckIndex].amount)}</p>
                                </div>
                                <div>
                                  <p className="text-xs text-muted-foreground">Amount in words</p>
                                  <p className="italic text-xs">
                                    {/* Simple word conversion for demo purposes */}
                                    {foundChecks[activeCheckIndex].amount.toFixed(2).replace(".", " dollars and ")}{" "}
                                    cents
                                  </p>
                                </div>
                              </div>

                              {/* Card and Memo */}
                              <div className="grid grid-cols-2 gap-4 mb-4">
                                <div>
                                  <p className="text-xs text-muted-foreground">Card Number</p>
                                  <div className="flex items-center space-x-2">
                                    <CreditCard className="h-3 w-3 text-slate-400" />
                                    <p className="text-sm">
                                      •••• •••• •••• {foundChecks[activeCheckIndex].creditCardNumber.slice(-4)}
                                    </p>
                                  </div>
                                </div>
                                <div>
                                  <p className="text-xs text-muted-foreground">Memo</p>
                                  <p className="italic text-sm">Payment for services</p>
                                </div>
                              </div>

                              {/* Signature Line */}
                              <div className="flex justify-end mt-4">
                                <div className="w-48">
                                  <div className="border-b-2 border-slate-300 dark:border-slate-700 h-8 flex items-end justify-end">
                                    <span className="italic text-slate-400 pb-1 text-sm">John Doe</span>
                                  </div>
                                  <p className="text-xs text-muted-foreground text-center mt-1">Authorized Signature</p>
                                </div>
                              </div>
                            </div>

                            {/* Check Footer */}
                            <div className="px-4 py-2 bg-slate-50 dark:bg-slate-800 text-xs border-t">
                              <div className="flex justify-between items-center">
                                <div className="flex items-center space-x-2">
                                  <span>Transaction ID: {foundChecks[activeCheckIndex].id}</span>
                                </div>
                                <div className="flex items-center space-x-1">
                                  <CheckCircle2 className="h-3 w-3 text-green-500" />
                                  <span>Verified</span>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
